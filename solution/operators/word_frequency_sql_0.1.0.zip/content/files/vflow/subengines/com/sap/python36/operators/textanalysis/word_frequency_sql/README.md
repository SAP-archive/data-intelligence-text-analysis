# Word frequency SQL - textanalysis.word_frequency_sql (Version: 0.0.1)

Word frequency SQL-statement generator

## Inport

* **articles** (Type: message.*) Trigger

## outports

* **log** (Type: string) Logging data
* **sql** (Type: string) sql statement

## Config

* **debug_mode** - Debug mode (Type: boolean) Sending debug level information to log port
* **language** - Language filter (Type: string) Language filter
* **type** - Type filter (Type: string) Type filter
* **min_count** - Minimum count of words (Type: integer) Minimum count of words


# Tags
sdi_utils : 

